import React, { useState, useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import SplashScreen from './src/screens/SplashScreen';
import HomeScreen from './src/screens/HomeScreen';

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Simula o tempo de carregamento da splash screen
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000); // 3 segundos

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <>
        <SplashScreen />
        <StatusBar style="auto" />
      </>
    );
  }

  return (
    <>
      <HomeScreen />
      <StatusBar style="auto" />
    </>
  );
}

