# Mobile App - React Native com TypeScript

Este é um aplicativo mobile desenvolvido com React Native, TypeScript, Expo e StyleSheet que exibe informações de IP obtidas da API IPinfo.

## Funcionalidades

- **Splash Screen**: Tela inicial de carregamento exibida por 3 segundos
- **Conexão com API**: Integração com a API IPinfo para obter dados dinâmicos
- **Exibição de Dados**: Apresentação organizada das informações de IP
- **Estilização**: Interface moderna usando StyleSheet
- **Tipagem**: Código totalmente tipado com TypeScript

## Estrutura do Projeto

```
mobile-app/
├── src/
│   ├── components/     # Componentes reutilizáveis
│   ├── screens/        # Telas da aplicação
│   │   ├── SplashScreen.tsx
│   │   └── HomeScreen.tsx
│   └── services/       # Serviços de API
│       └── api.ts
├── assets/             # Recursos estáticos
│   └── splash.png
├── App.tsx            # Componente principal
├── app.json           # Configurações do Expo
└── package.json       # Dependências do projeto
```

## Como Executar

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Execute o projeto:
   ```bash
   npm start
   ```

3. Use o Expo Go no seu dispositivo móvel ou um emulador para visualizar o app.

## API Utilizada

- **IPinfo**: Fornece informações sobre o endereço IP atual, incluindo localização, organização e fuso horário.

## Tecnologias

- React Native
- TypeScript
- Expo
- StyleSheet
- API IPinfo

