import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { getIPInfo, IPInfoData } from '../services/api';

const HomeScreen: React.FC = () => {
  const [ipData, setIpData] = useState<IPInfoData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchIPInfo();
  }, []);

  const fetchIPInfo = async () => {
    try {
      setLoading(true);
      const data = await getIPInfo();
      setIpData(data);
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível carregar as informações de IP');
      console.error('Erro ao buscar dados da API:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Carregando informações...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Informações de IP</Text>
        <Text style={styles.subtitle}>Dados obtidos da API IPinfo</Text>
      </View>

      {ipData && (
        <View style={styles.content}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Endereço IP</Text>
            <Text style={styles.cardValue}>{ipData.ip}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Localização</Text>
            <Text style={styles.cardValue}>
              {ipData.city}, {ipData.region}, {ipData.country}
            </Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Coordenadas</Text>
            <Text style={styles.cardValue}>{ipData.loc}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Organização</Text>
            <Text style={styles.cardValue}>{ipData.org}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Código Postal</Text>
            <Text style={styles.cardValue}>{ipData.postal}</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Fuso Horário</Text>
            <Text style={styles.cardValue}>{ipData.timezone}</Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666666',
  },
  header: {
    backgroundColor: '#007AFF',
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: '#ffffff',
    opacity: 0.8,
  },
  content: {
    padding: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666666',
    marginBottom: 5,
    textTransform: 'uppercase',
  },
  cardValue: {
    fontSize: 18,
    fontWeight: '500',
    color: '#333333',
  },
});

export default HomeScreen;

