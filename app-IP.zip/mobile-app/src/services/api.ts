// Interface para tipar os dados retornados pela API IPinfo
export interface IPInfoData {
  ip: string;
  city: string;
  region: string;
  country: string;
  loc: string;
  org: string;
  postal: string;
  timezone: string;
}

// Função para buscar informações de IP da API IPinfo
export const getIPInfo = async (): Promise<IPInfoData> => {
  try {
    const response = await fetch('https://ipinfo.io/json');
    
    if (!response.ok) {
      throw new Error(`Erro na requisição: ${response.status}`);
    }
    
    const data: IPInfoData = await response.json();
    return data;
  } catch (error) {
    console.error('Erro ao buscar dados da API IPinfo:', error);
    throw error;
  }
};

